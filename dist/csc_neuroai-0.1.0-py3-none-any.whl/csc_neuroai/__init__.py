"""
csc-neuroai: Autonomous Computational Stem Cell (CSC) self-repair framework.
"""

__version__ = "0.1.0"
__author__ = "Rijhul Lahariya"

from .core import hello

__all__ = ["hello", "__version__", "__author__"]

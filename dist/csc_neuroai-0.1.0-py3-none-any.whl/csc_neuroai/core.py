"""
Core module for csc-neuroai.
"""

def hello() -> str:
    return "Computational Stem Cells Ready."
